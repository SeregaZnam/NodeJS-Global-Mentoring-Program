INSERT INTO users (login, password, age) VALUES
  ('Alex', '123test', 15),
  ('Robin', 'asd456A', 20),
  ('Tony', 'sdf98xA', 25),
  ('Andrey', 'sdf298xA', 45),
  ('Sergey', '123wer', 25);