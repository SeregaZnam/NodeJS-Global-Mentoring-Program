export interface UserQuery {
	loginSubstring?: string;
	limit?: number | undefined;
	query?: any;
}
