export interface UserDTO {
	id: string;
	login: string;
	age: number;
}
